# CRAFTIX — Implementation Specification
**Project:** Android Minecraft Java Launcher  
**New application name:** CRAFTIX  
**New Android applicationId / package ID:** `com.craftix.launcher`  
**Current reference version shown in supplied mockup:** `0.7.7` (do not force this version if repository versioning differs)

This package is an implementation brief for the developer/AI coding agent. Treat the included visual references as design direction, not as permission to replace working engine code with mock UI.

---

## 1. Mandatory execution rules

1. Inspect the complete repository, current branch, build system, Android manifest, Gradle configuration, native Rust/JNI bridge, Flutter/Dart code (if present), and GitHub Actions workflows before editing.
2. Preserve the existing Minecraft engine, native Rust/wgpu/Vulkan integration, account/session storage, and working services. Do not rewrite or remove them merely to simplify UI work.
3. Implement real functionality. Do not add fake progress, fake download completion, fake installation, or buttons that only display success messages.
4. Run formatting, static analysis, unit tests, Android build, and workflow validation. Report exactly what passed and what could not be tested on a physical device.
5. Keep changes scoped, reviewable, and compatible with the repository's actual architecture. Do not assume a particular framework unless confirmed from source.
6. Before changing package ID or signing configuration, inspect existing identifiers and document migration implications.

## 2. Branding and identity

- Replace user-facing product branding `HORIZON` with `CRAFTIX` throughout launcher UI, app title, relevant metadata, splash screen, settings/about page, and release artifact naming.
- Subtitle: `Minecraft Java • Android`.
- Short tagline: `BUILD • PLAY • EXPLORE`.
- New Android applicationId: `com.craftix.launcher`.
- Use the included `assets/CRAFTIX_App_Icon_Reference.png` as visual guidance to create proper Android launcher icon assets in all required mipmap densities and adaptive icon foreground/background layers. Do not simply use the whole poster as the icon.
- Use `assets/CRAFTIX_UI_Visual_Reference.png` as the main visual reference.
- Brand palette:
  - Deep navy background: `#070B1D` / `#091322`
  - Card navy: `#111B38`
  - Electric purple: `#8B35F5`
  - Electric blue: `#315BFF`
  - Cyan accent: `#22D3EE`
  - Main text: `#F7F8FF`
  - Secondary text: `#A8B1CC`
  - Success/play state: accessible green, used sparingly.
- Maintain strong contrast, consistent spacing, rounded cards, subtle borders, controlled glow, and restrained gradients. Avoid excessive bloom that harms readability.

### Package ID migration warning

Changing `applicationId` to `com.craftix.launcher` makes Android treat CRAFTIX as a different installed app from an old Horizon package ID. It normally installs alongside the old app rather than updating it. Preserve user data where possible through a deliberate export/import migration, but do not promise automatic data migration across package IDs. Verify OAuth redirect URIs, app links, Firebase/Google configuration (if any), permissions, deep links, and native library package assumptions after the change.

## 3. Home screen: one stable page for download and play

The home screen must remain the same screen while game files/resources download.

### State A — not installed / resources missing
- Show a prominent `Download` action (Arabic/localized equivalent where translations exist).
- Explain what is being downloaded (Minecraft runtime/game files/assets) and the selected version.
- Tapping Download starts the real existing download/install pipeline.
- Do not navigate to a separate full-screen download page.
- Keep the hero image, version selector, account card, content-management cards, and bottom navigation in their same positions.

### State B — downloading
- Replace the Download button area with an embedded progress panel in the same location.
- Show actual progress from the downloader: percentage when known, downloaded bytes / total bytes, transfer speed, and estimated remaining time only when reliably calculable.
- If total size is unknown, show an indeterminate animated progress state; never invent a percentage.
- Show the current phase, e.g. resolving manifest, downloading libraries, downloading assets, verifying files, extracting/installing.
- Provide Pause/Resume only if the underlying downloader supports it; provide Cancel only if cancellation is safe and implemented.
- Keep the rest of the home page stable. No route change, layout jump, orientation change, or resizing during progress.

### State C — ready
- Show a clear `Play` button in the exact same action slot.
- Tapping Play launches the selected installed game profile using the actual engine/session path.
- If launch validation fails, show an actionable error without pretending the game launched.

### Interactive progress visual concept
Create a distinctive horizontal animated Minecraft-inspired progress strip:
- A small voxel/player character runs from left to right along a blocky ground track.
- The runner's position is driven by real download progress, not an unrelated timer.
- Small block/grass/ore pickups can appear at milestone thresholds (e.g. 25%, 50%, 75%, 100%) as decorative feedback; they must not obscure the numeric progress.
- At completion, show a short pickup/celebration animation (e.g. collecting a glowing block), then transition the panel to the ready/Play state.
- Include reduced-motion support and a non-animated fallback.
- Keep animation lightweight and battery-conscious. Do not add a large game-rendering dependency just for this animation.
- The progress bar must remain readable and accessible, with a clear numeric/phase label.

## 4. Fix navigation and screen resizing bugs

The current issue: tapping navigation/actions sometimes produces a visually broken screen and changes the apparent screen dimensions.

Requirements:
1. Establish one consistent app-level layout scaffold: safe areas/insets, stable system bars, consistent content width, and a single bottom navigation bar.
2. Navigation changes only the page content; it must not recreate the whole app shell or alter device window dimensions.
3. Use responsive constraints based on available width/height. Avoid hard-coded screen dimensions and nested scroll views with conflicting constraints.
4. Prevent overflow on narrow Android phones (including approximately 360 dp width).
5. Keep bottom navigation anchored and stable; account for Android gesture navigation and three-button navigation insets.
6. Prevent duplicate bottom bars, content behind system navigation, clipped cards, and sudden jumps caused by keyboard/insets.
7. Add smooth transitions between tabs (short fade/slide, consistent duration and easing). Respect reduced-motion settings.
8. Preserve orientation policy: launcher screens should use the intended portrait layout; the game/engine may enter landscape when needed. Do not force the launcher to resize or rotate when switching ordinary tabs.
9. Avoid unnecessary Activity recreation. Preserve selected tab, scroll position, and transient UI state when navigating where practical.
10. Test every bottom tab and key action repeatedly, including rapid taps and back navigation.

## 5. Screens and content

Maintain the existing main destinations and improve consistency:
- Home
- Mods
- Packs
- Installed
- Settings

On Home:
- CRAFTIX branding and icon.
- Minecraft hero banner.
- Download / progress / Play state slot.
- Minecraft version selector.
- Account/profile selector.
- Mods, Packs, Shaders, Installed summary cards.
- Performance information only when backed by real runtime metrics.

On Mods / Packs / Shaders:
- Keep search, source selector, version filters, loader filters, import/open-folder actions.
- Distinguish catalog browsing from installed local content.
- Clearly explain compatibility and installability.
- Do not show an Install button as functional if the backend cannot install that format.
- Do not label Java mods as runnable if the Rust client does not actually support the relevant Java loader/runtime.
- Use accurate statuses such as Compatible, Incompatible, Browse only, Unsupported format, Installed, or Download failed.
- Fix the misleading empty/no-results states and ensure source loading errors are recoverable with Retry.

## 6. Accounts

- Preserve Microsoft browser/device-code authentication and offline accounts.
- Fix regressions by tracing the actual OAuth/device-code flow, redirect handling, token persistence, refresh, and account selection.
- Never store Microsoft passwords.
- Do not log access tokens, refresh tokens, client secrets, or personal account data.
- Test both offline account creation/selection and Microsoft sign-in where test credentials/device access are available.
- Clearly distinguish signed-in Microsoft accounts from offline profiles.

## 7. Animation and interaction quality

- Use consistent transition timing and easing.
- Add subtle press feedback, card hover/selection states where applicable, loading shimmer only for actual loading, and skeletons only while data is pending.
- Avoid animating layout dimensions in ways that cause jumps.
- Keep all animations performant on mid-range Android devices.
- Do not use animations to disguise slow or failed operations.

## 8. Release signing — permanent key policy

**CRITICAL: Always reuse the exact CRAFTIX release keystore supplied by the project owner. Never generate a replacement key during routine builds, refactors, version bumps, branding changes, or CI repairs.**

GitHub Actions repository secrets have already been created by the owner with these exact names:
- `CRAFTIX_KEYSTORE_BASE64`
- `CRAFTIX_STORE_PASSWORD`
- `CRAFTIX_KEY_ALIAS`
- `CRAFTIX_KEY_PASSWORD`

Implementation requirements:
1. Read the existing workflows and Gradle signing configuration first.
2. Configure the Release build to decode `CRAFTIX_KEYSTORE_BASE64` into a temporary keystore file at build time, outside tracked source files.
3. Use the store password, alias, and key password from the corresponding GitHub Secrets.
4. Never print secret values, keystore Base64, passwords, or private key data in logs.
5. Never commit the `.jks`, Base64 text file, password file, or decoded temporary keystore.
6. Add/verify `.gitignore` entries for local keystore and signing property files.
7. Ensure debug builds can still build without release secrets, while release builds fail clearly if required secrets are missing.
8. Clean up temporary keystore files after signing, including on failure where feasible.
9. Verify the generated release APK/AAB is signed and record only the public SHA-256 certificate fingerprint for verification.
10. Add a CI check that compares the release signing certificate fingerprint against the expected CRAFTIX certificate fingerprint stored as a non-secret CI variable if desired. Never compare by exposing the private key.
11. Do not silently fall back to a newly generated key or debug signing for Release.
12. Keep the owner’s offline backup as the source of truth. If the key is lost, stop and notify the owner; do not create a new one automatically.

The keystore password and key password are sensitive. The coding agent must read them only from GitHub Secrets during CI and must not ask the user to paste them into source code, issues, pull requests, or chat.

### Existing certificate fingerprint supplied with this package
`77:05:07:A6:EC:48:51:98:66:55:08:29:32:CA:C2:81:61:55:08:0F:D4:73:DB:7E:42:E9:A0:BF:FD:22:DD:2F`

Treat this as a verification reference; confirm it against the actual keystore before relying on it.

### Important signing / package migration distinction
The new package ID `com.craftix.launcher` and the new signing key are separate changes. The package ID change itself means Android sees a different app identity from the old Horizon package. The new signing key also cannot update an already-installed Horizon app signed with a different certificate. Plan a clean CRAFTIX installation and a user-data migration/export strategy. Never claim seamless in-place upgrade unless Android signing and package identity conditions have been verified.

## 9. Suggested implementation order

1. Repository audit and baseline build/test report.
2. Package ID migration analysis and dependency/redirect audit.
3. Branding strings, app label, icon, splash screen, about/settings identity.
4. Stable app shell, safe-area/insets, navigation and responsive layout fixes.
5. Home screen download/ready state machine using real downloader events.
6. Animated Minecraft runner progress component and completion state.
7. Account-flow regression tests and fixes.
8. Mods/Packs/Shaders catalog and installation behavior audit; fix only verified backend paths.
9. GitHub Actions signing with the existing CRAFTIX secrets.
10. Build, tests, APK signature verification, and final report.

## 10. Acceptance checklist

- [ ] App displays CRAFTIX everywhere user-facing.
- [ ] Android applicationId is `com.craftix.launcher`.
- [ ] Correct adaptive launcher icon and splash assets are installed.
- [ ] Download appears only when required resources are missing.
- [ ] Download progress remains embedded in Home; no navigation away.
- [ ] Progress values reflect actual downloader state.
- [ ] Minecraft runner animation tracks real progress and has reduced-motion fallback.
- [ ] Completion changes the same action area to Play.
- [ ] Play launches the installed profile or shows a real actionable error.
- [ ] Tapping every tab keeps dimensions, safe areas, and bottom navigation stable.
- [ ] No overflow/clipping at 360 dp width.
- [ ] Portrait launcher and landscape game behavior are separated correctly.
- [ ] Microsoft and offline account flows are tested and regressions documented.
- [ ] Mod/pack/shader statuses accurately represent backend capabilities.
- [ ] Release CI uses the existing four CRAFTIX secrets.
- [ ] No private signing material is committed or printed.
- [ ] Release artifact signature matches the owner-provided CRAFTIX keystore.
- [ ] CI/build results and physical-device test results are reported separately.

## 11. Required final developer report

At completion, report:
- Files changed and purpose.
- New applicationId and any migration caveats.
- UI changes and animation behavior.
- Which account/catalog/download paths are genuinely functional.
- Build/test commands and exact outcomes.
- Whether an APK/AAB was generated.
- Signing certificate SHA-256 fingerprint (public certificate only).
- Any untested behavior or blockers.
- Never say “fully fixed” or “complete” for an item that was not tested.
